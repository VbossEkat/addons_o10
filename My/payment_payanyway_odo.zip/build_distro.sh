#!/bin/bash

zip -r payment_payanyway.zip ./payment_payanyway
