{
    'name': 'Website Code Snippet',
    'description': 'Embed Code fragments into your pages for demonstrating or teaching. Uses highlight.js',
    'version': '1.0',
    'author': 'Hibou Corp. <hello@hibou.io>',

    'data': [
        'views/snippets.xml',
    ],
    'category': 'Tools',
    'depends': ['website'],
}
