The module adds tracking odometer changes.

Tested on Odoo 8.0 115b0aebf706a318be8fda26f8478ca203269bf2
