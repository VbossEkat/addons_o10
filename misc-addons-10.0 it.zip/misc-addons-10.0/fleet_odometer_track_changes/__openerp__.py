# -*- coding: utf-8 -*-
{
    'name': 'Fleet with odometer track changes',
    'version': '0.1',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category': 'Managing vehicles and contracts',
    'website': 'https://yelizariev.github.io',
    'depends': ['fleet'],
    'data': [],
    'demo': [],
    'installable': False,
}
