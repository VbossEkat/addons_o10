===============================================
 Email confirmation on sign up (CRM extension)
===============================================

* Sign up as a new user
* Confirm registration by following link in an email
* Log in as Administrator
* Check that new lead is created
