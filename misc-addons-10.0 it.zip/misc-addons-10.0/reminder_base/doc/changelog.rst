`1.0.7`
-------
- Fix: compatibility with the "Mass Editing" module

`1.0.6`
-------
- Fix: some migration fixes for correct work in v10.0

`1.0.5`
-------
- PORT: support for 10.0

`1.0.4`
-------

- Fix: don't send mail to attendees after record creation or after date changing

`1.0.3`
-------

- Fix: check that partner record exists before add one to attendees

`1.0.2`
-------

- Fix unnecessary updating of calendar event

`1.0.1`
-------

- Fix: check for duplicates in attendees fields
