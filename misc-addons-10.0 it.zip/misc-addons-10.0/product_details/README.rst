=================
 Product Details
=================

The module allows to add models with details for product.

Credits
=======

Contributors
------------
* <krotov@it-projects.info>

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`_

Further information
===================

Demo: http://runbot.it-projects.info/demo/misc-addons/10.0

HTML Description: https://apps.odoo.com/apps/modules/10.0/product_details/

Usage instructions: `<doc/index.rst>`_

Changelog: `<doc/changelog.rst>`_

Tested on Odoo 10.0 260a3da768fbf1cd8c7d7ddb0e8f08aa3991e374

