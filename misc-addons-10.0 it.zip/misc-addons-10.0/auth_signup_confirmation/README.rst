===============================
 Email confirmation on sign up
===============================

When user tries to sign up he will get email with registration link. User follow this link and that way activates his account and may login as usual.

Credits
=======

Contributors
------------
* Ivan Yelizariev <yelizariev@it-projects.info>

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

Demo: http://runbot.it-projects.info/demo/misc-addons/9.0

HTML Description: https://apps.odoo.com/apps/modules/9.0/auth_signup_confirmation/

Usage instructions: `<doc/index.rst>`__

Changelog: `<doc/changelog.rst>`__

Tested on Odoo 9.0 fd9eb2e4819031c6758c021f4c335b591367632d
