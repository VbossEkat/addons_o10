===========
 Brand kit
===========

Allows to brand odoo:

* Branded name
* Color scheme
* Logo
* Favicon
* Login background page

Depends on ``web_debranding``.

Credits
=======

Contributors
------------
* Ivan Yelizariev <yelizariev@it-projects.info>

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`_

Further information
===================

Demo: http://runbot.it-projects.info/demo/misc-addons/9.0

HTML Description: https://apps.odoo.com/apps/modules/9.0/theme_kit/

Usage instructions: `<doc/index.rst>`_

Changelog: `<doc/changelog.rst>`_

Tested on Odoo 9.0 c902437247d36ca7945d30b8d75b55f4f7c4855e
