# -*- coding: utf-8 -*-
from . import base_details
