==========================
 Invoice multiorder lines
==========================


Usage
=====

* From ``Sales / Sales / Sales Orders Lines`` select the lines that you want to invoice
* Push on the ``[More]`` button and select ``Create grouped invoice`` option
* Open the created invoices from ``Invoicing / Customers / Customer Invoices`` 


