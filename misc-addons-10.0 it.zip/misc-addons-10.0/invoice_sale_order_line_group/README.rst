==========================
 Invoice multiorder lines
==========================

By using this module sales managers can create account invoice from chosen sale order lines. Sale order lines may be from different sale orders, but one grouped invoice will be created for each partner.

Credits
=======

Contributors
------------
* Ildar Nasyrov <Nasyrov@it-projects.info>

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

Usage instructions: `<doc/index.rst>`__

Changelog: `<doc/changelog.rst>`__

Tested on Odoo 8.0 f35fd798f1f5c4846fabf004934202b833abedd0
