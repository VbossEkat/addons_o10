====================
 Backend debranding
====================

For installation and configuration instructions see README.rst

Usage
=====

* Open Odoo
* RESULT: All reference to Odoo are gone in UI
