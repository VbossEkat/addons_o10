====================
 Customer Marketing
====================

The module allows to add detailed information about your customers. 
The module adds fields to store following information: Family, Occupation, Recreation, Motivation, Pets, Sport Teams.

Credits
=======

Contributors
------------
* <krotov@it-projects.info>

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`__

Maintainers
-----------
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

Demo: http://runbot.it-projects.info/demo/misc-addons/10.0

HTML Description: https://apps.odoo.com/apps/modules/10.0/customer_marketing/

Usage instructions: `<doc/index.rst>`_

Changelog: `<doc/changelog.rst>`_

Tested on Odoo 10.0 79d88494d6356a485c67a01e486eec60af552bf4
