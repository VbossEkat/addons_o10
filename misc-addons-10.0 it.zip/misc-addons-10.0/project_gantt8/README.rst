=========================
 Gantt view for Projects
=========================

The module adds Gantt view for Projects -- the same as it was in odoo 8.0

Credits
=======

Contributors
------------
* Pavel Romanchenko <romanchenko@it-projects.info>

Sponsors
--------
* `Associated Environmental Systems <https://www.associatedenvironmentalsystems.com/>`_

Donation
========

Feel free to help us maintain this and other modules by purchasing it at `app store <https://www.odoo.com/apps/modules/9.0/project_gantt8/>`_.

Further information
===================

Demo: http://runbot.it-projects.info/demo/misc-addons/9.0

HTML Description: https://apps.odoo.com/apps/modules/9.0/project_gantt8/

Usage instructions: `<doc/index.rst>`_

Changelog: `<doc/changelog.rst>`_

Tested on Odoo 9.0 b9bca7909aee5edd05d1cf81d45a540b7856f76e
