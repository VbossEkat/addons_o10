====================================
 hr public holidays import from ics
====================================

With this module you may generate holidays records
automatically from ics file.

Credits
=======

Contributors
------------
* Ildar Nasyrov <Nasyrov@it-projects.info>

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

Usage instructions: `<doc/index.rst>`__

Changelog: `<doc/changelog.rst>`__

Tested on Odoo 8.0 f35fd798f1f5c4846fabf004934202b833abedd0
