========================
 Production Lot Details
========================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Usage
=====

The module adds new fields in the production lot form view.
You can select a model and a record which will be stored production lot details.
To change list of model which contains details you have to inherit the ``_model_selection`` function. 
