# -*- coding: utf-8 -*-
from . import ir_attachment
from . import res_config
