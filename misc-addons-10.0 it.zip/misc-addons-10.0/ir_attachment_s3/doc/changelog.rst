`1.1.0`
-------

- **NEW:** All related to s3 settings is here now ``Settings >> Technical >> Database Structure >> S3 Settings``
- **NEW:** The new ``[Upload existing attachments]`` button on the ``Settings >> Technical >> Database Structure >> S3 Settings`` form that allows to upload existing attachments that correspond to an s3 condition, but for some reason are not stored on S3 yet (i.e. attachments that was created before this module had been installed)

`1.0.0`
-------

- Init version
