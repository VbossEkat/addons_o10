# -*- coding: utf-8 -*-
{
    'name': 'Show project\'s name with partner\'s name ',
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category': 'Custom',
    'website': 'https://yelizariev.github.io',
    'depends': ['project'],
    'data': [
        'views.xml',
    ],
    'installable': False
}
