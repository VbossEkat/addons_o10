Booking system calendar
=======================


Tested on Odoo 8.0 1af6b7dae28ec867e0d39f7952613f40dd317152
