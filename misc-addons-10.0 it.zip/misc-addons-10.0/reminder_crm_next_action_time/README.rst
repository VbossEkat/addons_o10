Reminders and Agenda for Opportunities (with time)
==================================================

The additional feature of this module is changing type the date to datetime of built-in date_action field.

Description: https://apps.odoo.com/apps/modules/10.0/reminder_crm_next_action_time/

Tested on Odoo 10.0 beaea311e6becd65dbb29925ba56016d4c249a68
