===================================================
 Reminders and Agenda for Opportunities (with time)
===================================================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Usage
=====

* Go to the 'Opportunities' menu
* Open or create Opportunity
* Fill 'Next Action' and select 'Reminders'
* Save the changes
