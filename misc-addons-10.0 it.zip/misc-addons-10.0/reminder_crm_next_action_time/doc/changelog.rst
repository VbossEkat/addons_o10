`1.0.1`
-------

- **FIX:** Reminder in the menu of next activity

`1.0.0`
-------

- Init version
