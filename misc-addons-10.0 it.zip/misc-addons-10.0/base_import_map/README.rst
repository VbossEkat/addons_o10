=================
 Import Settings
=================

The module allows to save import settings to don't specify columns to fields mapping each time.Put some short introduction first.

Credits
=======

Contributors
------------
* Dinar Gabbasov <gabbasov@it-projects.info>

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`_

Further information
===================

Demo: http://runbot.it-projects.info/demo/misc-addons/10.0

HTML Description: https://apps.odoo.com/apps/modules/10.0/base_import_map/

Usage instructions: `<doc/index.rst>`_

Changelog: `<doc/changelog.rst>`_

Tested on Odoo 10.0 dc6e7ca25ba4f1b5b6ce9c1857527e14ff919e31
