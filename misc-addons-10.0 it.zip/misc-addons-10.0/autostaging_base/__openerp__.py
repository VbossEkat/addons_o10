# -*- coding: utf-8 -*-
{
    'name': "Autostaging (technical core)",
    'author': "IT-Projects LLC, Ildar Nasyrov",
    'license': 'LGPL-3',
    'website': "https://twitter.com/nasyrov_ildar",
    'category': 'Autostaging',
    'version': '1.0.0',
    'data': [
        'data.xml',
    ],
    "installable": True
}
