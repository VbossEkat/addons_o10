Signature templates for user emails (HR)
========================================

Connector for modules:

* Signature templates for user emails
* HR

