FIX field limit in importing csv
================================

The module fix issue "field larger than field limit (131072)"
