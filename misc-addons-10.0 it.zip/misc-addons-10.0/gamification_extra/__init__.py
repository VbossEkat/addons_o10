# -*- coding: utf-8 -*-
from . import gamification_extra_models
