# -*- coding: utf-8 -*-
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html).

from . import ir_qweb
from . import ir_ui_view
from . import website_theme
from . import website
