# -*- coding: utf-8 -*-

from . import test_ir_config_parameter
from . import test_res_users
