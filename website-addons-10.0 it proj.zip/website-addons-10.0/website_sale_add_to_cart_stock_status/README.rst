Product status at website shop + Quick add items to shopping cart
=================================================================

If you have installed module **Product status at website shop** (technical name website_sale_stock_status) and want to add feature of the module **Quick add items to shopping cart** (technical name website_sale_add_to_cart), then you have to get this module, because quick add to cart buttons at */shop* directory should be hidden for discontinued products.

Tested on Odoo 8.0 f8d5a6727d3e8d428d9bef93da7ba6b11f344284

