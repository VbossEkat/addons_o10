Simplified website checkout
===========================

*The module is obsolete. Use website_sale_checkout_store instead*

Shoper type email address and receive message with sale order id. No payments, no deliveries.

Tested on Odoo 8.0 d023c079ed86468436f25da613bf486a4a17d625
