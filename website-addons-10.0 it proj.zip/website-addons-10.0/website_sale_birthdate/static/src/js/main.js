 $(document).ready(function() {
     $('input[name="birthdate"]').pickmeup_twitter_bootstrap({
         default_date: false
     });
});
