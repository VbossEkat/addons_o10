# -*- coding: utf-8 -*-
{
    'name': "website_sale_birthdate",
    'author': "IT-Projects LLC, Ivan Yelizariev",
    'license': 'LGPL-3',
    "support": "apps@it-projects.info",
    'website': "https://yelizariev.github.io",
    'category': 'eCommerce',
    'version': '1.0',
    'depends': ['website_sale', 'partner_person'],
    'data': [
        'views.xml',
    ],
    'installable': False
}
