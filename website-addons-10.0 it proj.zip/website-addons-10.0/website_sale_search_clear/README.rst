Website Sale Search Clear
=========================

* product search is made to be global to all products no matter what category the person is in at the time.
* clear the search if the person clicks on any category link so the results are not filtered anymore.

Tested on Odoo 8.0 f8d5a6727d3e8d428d9bef93da7ba6b11f344284
