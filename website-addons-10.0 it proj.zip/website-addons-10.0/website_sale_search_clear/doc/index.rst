==========================
 Website Sale Search Clear
==========================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Usage
=====

* Go to Website >> Shop
* Then 2 cases are possible to use it
* Case 1:
  * Open a category link
  * Type a sentence in the search field
  * Click on the search button
  * The results are displayed regardless of what category you are in.
* Case 2:
  * Type a sentence in the search field
  * Click on the search button
  * Click on any category link
  * The search is cleared

