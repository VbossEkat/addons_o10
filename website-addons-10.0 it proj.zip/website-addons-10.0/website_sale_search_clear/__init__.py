# -*- coding: utf-8 -*-
from . import controllers


def post_load():
    from . import query_url
