====================================
 Demo Data for "Real Multi Website"
====================================

After installation:

* Log out from database or open new incognito window
* Log in to database. At this moment module updates website settings according
  to domain you use. You need to do it only once.
* Open ``Website Admin >> Configuration >> Websites`` -- you can see list of websites with domain addresses
* Open one of addreses -- it opens related website

For more information see Documentation for `Real Multi Website <https://apps.odoo.com/apps/modules/10.0/website_multi_company_demo>`_ module.
