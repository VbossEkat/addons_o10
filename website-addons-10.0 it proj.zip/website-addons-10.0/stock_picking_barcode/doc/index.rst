===========================================
 Barcode scanner support for Stock Picking
===========================================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Configuration
=============

* This module does not require special configuration.

Usage
=====

* Open barcode scanning page

  * either click barcode icon at ``Inventory / Dashboard`` menu
  * or select some Stock Picking and click barcode icon there

* Scan product barcode;

* Quantity of scanned product is increased;
