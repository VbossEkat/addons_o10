`1.0.3`
-------

- **FIX** Fixed problem with creation of extra movements.

`1.0.2`
-------

- **FIX** Issue related to scanning a location barcode

`1.0.1`
-------

- **PORT** Ported to Odoo 10.

`1.0.0`
-------

- Init version
