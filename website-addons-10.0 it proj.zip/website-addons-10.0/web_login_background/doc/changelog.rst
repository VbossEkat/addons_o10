`1.0.1`
-------

- IMP: Background used on signup page too.
- IMP: Round corners on form.

`1.0.0`
-------

- init version
