`1.0.3`
-------

- FIX: Compatibility with website_sale_suggest_create_account, website_sale_require_login, website_event_sale

`1.0.2`
-------

- FIX: fields depend on a type of delivery/payment

`1.0.1`
-------

- FIX: fixed issues for v10

`1.0.0`
-------

- init version
