Hide quantity field in web shop
===============================

Allows customise option "Select quantity" per product.

Also, adds option 'Sale max 1 item'

Tested on Odoo 8.0 f89220a51313e1bf46ec82175f2449c2e1a0455c
