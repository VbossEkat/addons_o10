Sale only available products on Website
=======================================

TODO
----
* Check quantity for "Stockable Product" only. See `#104 <https://github.com/it-projects-llc/website-addons/pull/104>`__

Tested on Odoo 9.0 aa09c522053b8c91dea557f9e9e71be2f4e965be
