=========================================
 Sale only available products on Website
=========================================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way


Usage
=====

* Open the shop and choose any product
* Click ``Add to cart``
* RESULT:

  * In the right column a quantity of available products displays
  * If there are no available products, the corresponding row is colored as red and you're not allowed to continue checkout process
