Custom website search
=====================

The module is obsolete. Use following modules instead:
https://www.odoo.com/apps/modules/9.0/website_sale_search_clear
https://www.odoo.com/apps/modules/9.0/website_sale_search_tags

Odoo 11.0+
==========

Not maintained since v. 11.0.
