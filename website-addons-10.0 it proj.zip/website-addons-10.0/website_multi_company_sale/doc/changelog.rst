`1.0.1`
-------

- **FIX:** add multi-company support for carts

`1.0.0`
-------

- Init version
