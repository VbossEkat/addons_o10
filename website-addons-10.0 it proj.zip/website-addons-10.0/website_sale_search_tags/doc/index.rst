=========================
 Website Sale Search Tags
=========================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Usage
=====

* Go to Sales >> Products
* Open or create a product
* Specify a product tag
* Then go to Website >> Shop
* Type a tag specified in a product into the search field
* Click on the search button
* See the results


