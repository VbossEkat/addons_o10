Website Sale Search Tags
========================

* adds results from searching by tags

Tested on Odoo 8.0 f8d5a6727d3e8d428d9bef93da7ba6b11f344284
