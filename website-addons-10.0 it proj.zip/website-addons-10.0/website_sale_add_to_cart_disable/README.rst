=============================================
 Hide "Add To Cart" button from product page
=============================================

Allows to disable product sales via eCommerce for any reason.

Credits
=======

Contributors
------------
* Ivan Yelizariev <yelizariev@it-projects.info>

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

Demo: http://runbot.it-projects.info/demo/website-addons/8.0

Usage instructions: `<doc/index.rst>`__

Changelog: `<doc/changelog.rst>`__

Tested on Odoo 8.0 bde083a5f91a659430b1227f240872f912f23c12
