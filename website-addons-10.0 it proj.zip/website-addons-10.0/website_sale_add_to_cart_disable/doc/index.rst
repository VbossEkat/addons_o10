=============================================
 Hide "Add To Cart" button from product page
=============================================

Usage
=====

* Open product form (e.g. via ``Sale / Products / Products``)
* Switch ``[x] Show Add To Cart button`` off if needed
* Open the product in eCommerce -- ``Add To Cart`` button is hidden
