=========================
 Website Login Background
=========================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way


Usage
=====

* Go to Settings ``Technical >> Database Structure >> Attachments``
* Click ``[Create]``
* Upload an image file
* Mark the "Use as a login page background" box
* Click ``[Save]``
* Go to your website
* Open login page and see the image as a background