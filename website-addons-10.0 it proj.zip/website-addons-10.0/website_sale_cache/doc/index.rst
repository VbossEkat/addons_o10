===================
 Website sale cache
===================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__

Configuration
=============

The module does not need to be pre-configured.


Usage
=====
Enable the display of product categories on website by using the customize menu at the upper right corner.
Once the categories are cached after first load, the page loading speed will be increased.


Demo: http://runbot.it-projects.info/demo/website-addons/9.0

HTML Description: https://apps.odoo.com/apps/modules/9.0/website_sale_cache/
