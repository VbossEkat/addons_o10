=======================================
 Configurable SEO URL (Technical core)
=======================================

This is a technical module. You need to install another module that extends model you need. E.g. ``website_seo_url_product`` extends ``product.template`` model, so you can use custom SEO URLs at eCommerce.


