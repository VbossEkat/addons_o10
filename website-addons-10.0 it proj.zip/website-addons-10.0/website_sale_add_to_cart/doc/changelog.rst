`1.0.1`
-------

- [FIX] Adding products from product screen

`1.0.0`
-------

- Init version
