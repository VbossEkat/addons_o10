Quick add items to shopping cart
================================

Description: https://apps.odoo.com/apps/modules/8.0/website_sale_add_to_cart/

Tested on Odoo 10.0 13d2b29f0151a9f607df96246104f30bb49cae86
