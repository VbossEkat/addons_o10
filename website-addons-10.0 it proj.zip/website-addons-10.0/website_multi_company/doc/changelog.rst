`1.2.3`
-------

- **FIX:** fix multi-theme for themes that have theme-like dependencies (problem with views that have position="replace")

`1.2.2`
-------

- **FIX:** fix multi-theme for themes that have theme-like dependencies

`1.2.0`
-------

- **FIX:** allow install several themes at once
- **ADD:** support of custom themes

`1.1.0`
-------

- **ADD:** multi-theme support
- **ADD:** multi-favicon support

`1.0.0`
-------

- Init version
